<?php

return [
    'whatsapp' => env('STORE_WHATSAPP', '6281234567890'),
    'bank' => env('STORE_BANK', 'BCA 1234567890 a.n. Pak Har'),
    'address' => 'Jl. Contoh No. 1, Jakarta',
    'email' => 'cs@pakhar-game.test',
    'hours' => 'Senin - Jumat : 09.00 - 17.00',
];
