@extends('layouts.app')
@section('title', 'Login')

@section('content')
    <div class="auth-wrap">
        <div class="auth-side">
            <div class="ghost-sm">LOGIN</div>
            <h2>Masuk untuk lanjut belanja</h2>
            <p style="opacity:.85;margin:0">Login diperlukan sebelum membeli dan melunasi pembayaran.</p>
            <img src="{{ asset('images/products/controller-white.svg') }}" alt="">
        </div>
        <div class="auth-form">
            <h1>Login</h1>
            <p class="sub">Belum punya akun? <a href="{{ route('register') }}" style="color:var(--red);font-weight:600">Daftar sekarang</a></p>

            @if (session('url.intended'))
                <div class="alert alert-info">Silakan login dulu. Setelah login kamu akan dikembalikan ke halaman sebelumnya.</div>
            @endif

            <form method="POST" action="{{ route('login.attempt') }}">
                @csrf
                <div class="field">
                    <label>Email</label>
                    <input type="email" name="email" value="{{ old('email') }}" required autofocus>
                    @error('email')<div class="error-text">{{ $message }}</div>@enderror
                </div>
                <div class="field">
                    <label>Password</label>
                    <input type="password" name="password" required>
                    @error('password')<div class="error-text">{{ $message }}</div>@enderror
                </div>
                <label style="display:flex;gap:8px;align-items:center;font-weight:400">
                    <input type="checkbox" name="remember" value="1"> Ingat saya
                </label>
                <button class="btn btn-red btn-block" style="margin-top:18px">Login</button>
            </form>
            <p style="font-size:12px;color:var(--muted);margin-top:20px">Akun demo: <b>user@pakhar.test</b> / <b>password</b></p>
        </div>
    </div>
@endsection
