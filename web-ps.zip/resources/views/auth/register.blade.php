@extends('layouts.app')
@section('title', 'Daftar Akun')

@section('content')
    <div class="auth-wrap">
        <div class="auth-side">
            <div class="ghost-sm">JOIN</div>
            <h2>Buat akun baru</h2>
            <p style="opacity:.85;margin:0">Data kamu otomatis terisi saat checkout, dan riwayat pesanan tersimpan rapi.</p>
            <img src="{{ asset('images/products/headset.svg') }}" alt="">
        </div>
        <div class="auth-form">
            <h1>Daftar</h1>
            <p class="sub">Sudah punya akun? <a href="{{ route('login') }}" style="color:var(--red);font-weight:600">Login</a></p>
            <form method="POST" action="{{ route('register.store') }}">
                @csrf
                <div class="field">
                    <label>Nama Lengkap</label>
                    <input type="text" name="name" value="{{ old('name') }}" required>
                    @error('name')<div class="error-text">{{ $message }}</div>@enderror
                </div>
                <div class="grid-2">
                    <div class="field">
                        <label>Email</label>
                        <input type="email" name="email" value="{{ old('email') }}" required>
                        @error('email')<div class="error-text">{{ $message }}</div>@enderror
                    </div>
                    <div class="field">
                        <label>No. HP</label>
                        <input type="text" name="phone" value="{{ old('phone') }}" required>
                        @error('phone')<div class="error-text">{{ $message }}</div>@enderror
                    </div>
                </div>
                <div class="grid-2">
                    <div class="field">
                        <label>Password</label>
                        <input type="password" name="password" required>
                        @error('password')<div class="error-text">{{ $message }}</div>@enderror
                    </div>
                    <div class="field">
                        <label>Ulangi Password</label>
                        <input type="password" name="password_confirmation" required>
                    </div>
                </div>
                <button class="btn btn-red btn-block">Daftar</button>
            </form>
        </div>
    </div>
@endsection
