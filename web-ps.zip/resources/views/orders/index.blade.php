@extends('layouts.app')
@section('title', 'Pesanan Saya')

@section('content')
    <div class="page-head">
        <div class="crumb"><a href="{{ route('home') }}">Home</a> / Akun</div>
        <h1>Pesanan Saya</h1>
        <div class="ghost">ORDER</div>
    </div>

    @if ($orders->isEmpty())
        <div class="empty">Belum ada pesanan.</div>
    @else
        <div class="card">
            <table class="table">
                <thead><tr><th>Invoice</th><th class="hide-sm">Tanggal</th><th>Total</th><th>Status</th><th></th></tr></thead>
                <tbody>
                @foreach ($orders as $o)
                    <tr>
                        <td><b>{{ $o->invoice }}</b></td>
                        <td class="hide-sm">{{ $o->created_at->format('d/m/Y H:i') }}</td>
                        <td>@rupiah($o->grand_total)</td>
                        <td><span class="pill pill-{{ $o->status }}">{{ $o->statusLabel() }}</span></td>
                        <td style="text-align:right">
                            <a href="{{ route('orders.show', $o->invoice) }}" class="btn btn-outline btn-sm">Detail</a>
                            @if ($o->status === 'menunggu_pembayaran' && $o->payment_method_id === \App\Models\Order::PAYMENT_TRANSFER)
                                <a href="{{ route('payment.form', ['invoice' => $o->invoice]) }}" class="btn btn-red btn-sm">Konfirmasi</a>
                            @endif
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        @include('partials.pagination', ['paginator' => $orders, 'pageUrl' => fn ($p) => $orders->url($p)])
    @endif
@endsection
