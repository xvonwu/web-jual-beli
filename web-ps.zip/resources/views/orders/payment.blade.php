@extends('layouts.app')
@section('title', 'Konfirmasi Pembayaran')

@section('content')
    <div class="page-head">
        <div class="crumb"><a href="{{ route('home') }}">Home</a> / Payment Confirmation</div>
        <h1>Konfirmasi Pembayaran</h1>
        <div class="ghost">PAYMENT</div>
    </div>

    <div class="layout-2">
        <div class="card">
            <p style="margin-top:0;color:#555">Apabila kamu sudah melakukan transfer, silakan isi form berikut ini.</p>

            @if ($orders->isEmpty())
                <div class="empty">Tidak ada invoice yang menunggu pembayaran transfer.<br><br>
                    <a href="{{ route('orders.index') }}" class="btn btn-outline">Lihat Pesanan Saya</a></div>
            @else
                <form method="POST" action="{{ route('payment.save') }}">
                    @csrf
                    <div class="field">
                        <label>No. Invoice</label>
                        <select name="invoice" required>
                            @foreach ($orders as $o)
                                <option value="{{ $o->invoice }}" @selected(old('invoice', $selected) === $o->invoice)>
                                    {{ $o->invoice }} — Rp {{ number_format($o->grand_total, 0, ',', '.') }}
                                </option>
                            @endforeach
                        </select>
                        @error('invoice')<div class="error-text">{{ $message }}</div>@enderror
                    </div>
                    <div class="grid-2">
                        <div class="field"><label>Email *</label><input type="email" name="email" value="{{ old('email', $user->email) }}" required></div>
                        <div class="field"><label>Nama Customer</label><input type="text" name="nama" value="{{ old('nama', $user->name) }}" required></div>
                    </div>
                    <div class="grid-2">
                        <div class="field">
                            <label>Tanggal Transfer</label>
                            <input type="date" name="tgl_transfer" value="{{ old('tgl_transfer', date('Y-m-d')) }}" required>
                            @error('tgl_transfer')<div class="error-text">{{ $message }}</div>@enderror
                        </div>
                        <div class="field">
                            <label>Jumlah Transfer (Rp)</label>
                            <input type="number" name="jml_transfer" value="{{ old('jml_transfer') }}" min="1" required>
                            @error('jml_transfer')<div class="error-text">{{ $message }}</div>@enderror
                        </div>
                    </div>
                    <div class="field"><label>No. Rekening Tujuan Transfer</label><input type="text" name="rekening_tujuan" value="{{ old('rekening_tujuan', config('store.bank')) }}" required></div>
                    <div class="grid-2">
                        <div class="field"><label>Transfer dari Bank</label><input type="text" name="dari_bank" value="{{ old('dari_bank') }}" placeholder="BCA / Mandiri / BRI ..." required></div>
                        <div class="field"><label>Nama Pemilik Rekening Pengirim</label><input type="text" name="rekening_pengirim" value="{{ old('rekening_pengirim') }}" required></div>
                    </div>
                    <button class="btn btn-red">Kirim Konfirmasi</button>
                </form>
            @endif
        </div>
        <aside class="card">
            <h3 style="margin-top:0">Kantor {{ config('app.name') }}</h3>
            <p style="margin:0 0 8px;color:#555">{{ config('store.address') }}</p>
            <p style="margin:0 0 8px;color:#555">{{ config('store.email') }}</p>
            <h4 style="margin:20px 0 6px">Jam Kerja</h4>
            <p style="margin:0;color:#555">{{ config('store.hours') }}<br>Sabtu - Minggu &amp; tanggal merah: Libur</p>
        </aside>
    </div>
@endsection
