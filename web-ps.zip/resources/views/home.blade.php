@extends('layouts.app')

@section('content')
    {{-- ================= HERO (gaya "Wireless HEADPHONE") ================= --}}
    <section class="hero">
        <div class="ghost">PLAYSTATION</div>
        <div class="hero-text">
            <small>PlayStation 5</small>
            <h1>Slim<br>Console</h1>
            <a href="{{ isset($cat[161]) ? $cat[161]->url() : route('search') }}" class="btn btn-red">Shop By Category</a>
        </div>
        <div class="hero-img">
            <img src="{{ asset('images/products/console-ps5.svg') }}" alt="PS5 Console">
            <img class="pad" src="{{ asset('images/products/controller-white.svg') }}" alt="DualSense">
        </div>
        <div class="hero-desc">
            <b>Description</b>
            <p>Konsol PS5 original bergaransi resmi. Main game generasi terbaru dengan loading super cepat dan DualSense.</p>
        </div>
    </section>

    {{-- ================= KARTU KATEGORI BARIS 1 ================= --}}
    @php
        $u = fn ($id) => isset($cat[$id]) ? $cat[$id]->url() : route('search');
    @endphp
    <section class="cat-grid">
        <a href="{{ $u(173) }}" class="cat-card c-dark">
            <div class="txt">
                <small>Enjoy</small>
                <h3>With</h3>
                <div class="ghost-sm">HEADSET</div>
                <span class="btn btn-red btn-sm">Browse</span>
            </div>
            <img src="{{ asset('images/products/headset.svg') }}" alt="Headset">
        </a>
        <a href="{{ $u(163) }}" class="cat-card c-yellow">
            <div class="txt">
                <small>New</small>
                <h3>Play</h3>
                <div class="ghost-sm" style="color:#fff;opacity:.55">PAD</div>
                <span class="btn btn-white btn-sm">Browse</span>
            </div>
            <img src="{{ asset('images/products/controller-black.svg') }}" alt="Controller">
        </a>
        <a href="{{ $u(162) }}" class="cat-card c-red wide">
            <div class="txt">
                <small>Trend</small>
                <h3>Games</h3>
                <div class="ghost-sm">PS5 GAMES</div>
                <span class="btn btn-white btn-sm">Browse</span>
            </div>
            <img src="{{ asset('images/covers/ps5-resident-evil-requiem-game.svg') }}" alt="Games PS5" style="width:22%;right:27%;bottom:28px;transform:rotate(-6deg);border-radius:10px">
            <img src="{{ asset('images/covers/ps5-007-first-light-game.svg') }}" alt="" style="width:22%;right:6%;bottom:20px;transform:rotate(6deg);border-radius:10px">
        </a>
    </section>

    {{-- ================= KARTU KATEGORI BARIS 2 ================= --}}
    <section class="cat-grid row2">
        <a href="{{ $u(161) }}" class="cat-card c-gray wide">
            <div class="txt">
                <small>Best</small>
                <h3>Gaming</h3>
                <div class="ghost-sm">CONSOLE</div>
                <span class="btn btn-red btn-sm">Browse</span>
            </div>
            <img src="{{ asset('images/products/console-ps5.svg') }}" alt="Console" style="width:36%;right:8%">
        </a>
        <a href="{{ $u(35) }}" class="cat-card c-green">
            <div class="txt">
                <small>Play</small>
                <h3>Game</h3>
                <div class="ghost-sm">OCULUS</div>
                <span class="btn btn-white btn-sm">Browse</span>
            </div>
            <img src="{{ asset('images/products/vr.svg') }}" alt="VR">
        </a>
        <a href="{{ $u(165) }}" class="cat-card c-blue">
            <div class="txt">
                <small>New</small>
                <h3>XBOX</h3>
                <div class="ghost-sm">SERIES</div>
                <span class="btn btn-white btn-sm">Browse</span>
            </div>
            <img src="{{ asset('images/products/console-xbox.svg') }}" alt="XBOX">
        </a>
    </section>

    {{-- ================= FITUR ================= --}}
    <section class="features">
        <div class="feature">@include('partials.icon', ['n' => 'truck'])<div><b>Pengiriman Cepat</b><span>JNE, J&amp;T, GOJEK, Grab</span></div></div>
        <div class="feature">@include('partials.icon', ['n' => 'shield'])<div><b>Garansi Resmi</b><span>100% original &amp; segel</span></div></div>
        <div class="feature">@include('partials.icon', ['n' => 'headset'])<div><b>Support WhatsApp</b><span>{{ config('store.hours') }}</span></div></div>
        <div class="feature">@include('partials.icon', ['n' => 'wallet'])<div><b>Pembayaran Aman</b><span>Transfer BCA / Cash</span></div></div>
    </section>

    {{-- ================= PREORDER ================= --}}
    @if ($preorders->isNotEmpty())
        <section class="section">
            <div class="section-head"><h2>Preorder <span>Now</span></h2><a href="{{ route('preorder') }}">Lihat semua &rarr;</a></div>
            <div class="products">
                @foreach ($preorders as $p) @include('partials.product-card') @endforeach
            </div>
        </section>
    @endif

    {{-- ================= NEW RELEASE ================= --}}
    <section class="section">
        <div class="section-head"><h2>New <span>Release</span></h2><a href="{{ route('search') }}">Lihat semua &rarr;</a></div>
        <div class="products">
            @forelse ($newReleases as $p) @include('partials.product-card') @empty
                <div class="empty" style="grid-column:1/-1">Belum ada produk. Jalankan <code>php artisan migrate --seed</code>.</div>
            @endforelse
        </div>
    </section>

    {{-- ================= LATEST UPDATES ================= --}}
    <section class="section">
        <div class="section-head"><h2>Latest <span>Updates</span></h2><a href="{{ route('promo') }}">Lihat promo &rarr;</a></div>
        <div class="products">
            @foreach ($latest as $p) @include('partials.product-card') @endforeach
        </div>
    </section>
@endsection
