@extends('layouts.app')
@section('title', 'Keranjang Belanja')

@section('content')
    <div class="page-head">
        <div class="crumb"><a href="{{ route('home') }}">Home</a> / Shopping Cart</div>
        <h1>Keranjang Belanja</h1>
        <div class="ghost">CART</div>
    </div>

    @if ($errors->any())
        <div class="alert alert-error">{{ $errors->first() }}</div>
    @endif

    @if ($items->isEmpty())
        <div class="empty">
            Keranjang belanja kamu masih kosong.<br><br>
            <a href="{{ route('home') }}" class="btn btn-red">Mulai Belanja</a>
        </div>
    @else
        <div class="layout-2">
            <div>
                {{-- ===== Daftar produk ===== --}}
                <div class="card" style="margin-bottom:24px">
                    <table class="table">
                        <thead>
                        <tr><th colspan="2">Nama Produk</th><th class="hide-sm">Harga Satuan</th><th>Jumlah</th><th>Sub-Total</th><th></th></tr>
                        </thead>
                        <tbody>
                        @foreach ($items as $item)
                            <tr>
                                <td style="width:70px"><div class="mini"><img src="{{ $item->product->imageUrl() }}" alt=""></div></td>
                                <td><a href="{{ $item->product->url() }}">{{ $item->product->name }}</a></td>
                                <td class="hide-sm">@rupiah($item->product->price)</td>
                                <td>
                                    <form method="POST" action="{{ route('cart.update', $item) }}" class="qty-form">
                                        @csrf @method('PATCH')
                                        <input type="number" name="qty" value="{{ $item->qty }}" min="1" onchange="this.form.submit()">
                                    </form>
                                </td>
                                <td><b>@rupiah($item->subtotal())</b></td>
                                <td>
                                    <form method="POST" action="{{ route('cart.remove', $item) }}">
                                        @csrf @method('DELETE')
                                        <button class="link-del" title="Hapus">&times;</button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                    <form method="POST" action="{{ route('cart.clear') }}" style="margin-top:12px" onsubmit="return confirm('Kosongkan semua isi keranjang?')">
                        @csrf
                        <button class="link-del">[Hapus Semua]</button>
                    </form>
                </div>

                {{-- ===== STEP 1: Cara pengiriman -> POST /hitung_ongkir ===== --}}
                @php
                    $s = $shipping['data'] ?? [];
                    $type = old('jenisongkir', $s['jenisongkir'] ?? 'pickup');
                @endphp
                <div class="card" style="margin-bottom:24px">
                    <h3 class="step-title"><span class="step">1</span> Pilih Cara Pengiriman</h3>
                    <form method="POST" action="{{ route('cart.shipping') }}" id="shippingForm">
                        @csrf
                        <input type="hidden" name="jenisongkir" value="{{ $type }}">
                        <div class="tabs">
                            @foreach (\App\Models\Order::COURIERS as $key => $label)
                                <button type="button" class="tab" data-type="{{ $key }}">{{ $label }}</button>
                            @endforeach
                        </div>
                        <div class="tab-note"></div>

                        <div class="grid-2">
                            <div class="field">
                                <label>Nama Penerima</label>
                                <input type="text" name="namatemp" value="{{ old('namatemp', $s['namatemp'] ?? $user->name) }}" required>
                            </div>
                            <div class="field">
                                <label>No. HP / WhatsApp</label>
                                <input type="text" name="hptemp" value="{{ old('hptemp', $s['hptemp'] ?? $user->phone) }}" required>
                            </div>
                        </div>
                        <div class="field">
                            <label>Email</label>
                            <input type="email" name="emailtemp" value="{{ old('emailtemp', $s['emailtemp'] ?? $user->email) }}" required>
                        </div>
                        <div class="field" data-show="gojek grab jne jnt">
                            <label>Alamat Lengkap</label>
                            <textarea name="alamattemp" rows="3">{{ old('alamattemp', $s['alamattemp'] ?? $user->address) }}</textarea>
                        </div>
                        <div class="grid-2" data-show="jne jnt">
                            <div class="field">
                                <label>Kota Tujuan</label>
                                <select name="kotatemp">
                                    <option value="">— Pilih kota —</option>
                                    @foreach ($cities as $city)
                                        <option value="{{ $city }}" @selected(old('kotatemp', $s['kotatemp'] ?? '') === $city)>{{ $city }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="field">
                                <label>Kode Pos</label>
                                <input type="text" name="ziptemp" value="{{ old('ziptemp', $s['ziptemp'] ?? '') }}">
                            </div>
                        </div>
                        <button class="btn btn-dark">Hitung Ongkir</button>
                    </form>
                </div>

                {{-- ===== STEP 2: Pembayaran -> POST /checkout_proses ===== --}}
                <div class="card" id="pembayaran">
                    <h3 class="step-title"><span class="step">2</span> Pilih Cara Pembayaran</h3>
                    @if (! $shipping['data'])
                        <div class="alert alert-info" style="margin-top:0">Isi cara pengiriman lalu klik <b>Hitung Ongkir</b> terlebih dahulu.</div>
                    @endif
                    @php $isPickup = ($shipping['data']['jenisongkir'] ?? null) === 'pickup'; @endphp
                    <form method="POST" action="{{ route('checkout') }}">
                        @csrf
                        <label class="radio">
                            <input type="radio" name="payment_method_id" value="{{ \App\Models\Order::PAYMENT_TRANSFER }}" checked>
                            <span><b>Transfer ke BCA</b><br><small style="color:var(--muted)">{{ config('store.bank') }}</small></span>
                        </label>
                        <label class="radio {{ $isPickup ? '' : 'disabled' }}">
                            <input type="radio" name="payment_method_id" value="{{ \App\Models\Order::PAYMENT_CASH }}" @disabled(! $isPickup)>
                            <span><b>Cash di kantor</b><br><small style="color:var(--muted)">Khusus pengambilan langsung di kantor</small></span>
                        </label>

                        <div class="field" style="margin-top:16px">
                            <label>Kupon Promo</label>
                            <input type="text" name="kupon" value="{{ old('kupon') }}" placeholder="Kosongkan bila tidak ada (contoh: HEMAT10)">
                        </div>
                        <div class="field">
                            <label>Catatan Khusus</label>
                            <textarea name="comment" rows="2" placeholder="Permintaan khusus, tulis di sini">{{ old('comment') }}</textarea>
                        </div>
                        <button class="btn btn-red btn-block" @disabled(! $shipping['data'])>Bayar Sekarang</button>
                    </form>
                </div>
            </div>

            {{-- ===== Ringkasan ===== --}}
            <aside class="card" style="position:sticky;top:96px">
                <h3 style="margin:0 0 14px">Total Belanja</h3>
                <div class="summary-row"><span>Subtotal</span><span>@rupiah($subtotal)</span></div>
                <div class="summary-row">
                    <span>Ongkos Kirim</span>
                    <span>{{ $shipping['data'] ? 'Rp '.number_format($shipping['cost'], 0, ',', '.') : '-' }}</span>
                </div>
                @if ($shipping['data'])
                    <div style="font-size:12px;color:var(--muted);text-align:right">
                        {{ \App\Models\Order::COURIERS[$shipping['data']['jenisongkir']] }} · {{ $shipping['note'] }}
                    </div>
                @endif
                <div class="summary-row total"><span>Grand Total</span><span class="price">@rupiah($subtotal + $shipping['cost'])</span></div>
                <p style="font-size:12px;color:var(--muted);margin:10px 0 0">Diskon kupon dihitung saat klik <b>Bayar Sekarang</b>.</p>
            </aside>
        </div>
    @endif
@endsection
