@extends('layouts.app')
@section('title', $title)

@section('content')
    <div class="page-head">
        <div class="crumb"><a href="{{ route('home') }}">Home</a> @foreach ($breadcrumb as $b) / {{ $b }} @endforeach</div>
        <h1>{{ $title }}</h1>
        <div class="ghost">{{ strtoupper($breadcrumb[0] ?? 'SHOP') }}</div>
    </div>

    @isset($q)
        <form action="{{ route('search') }}" method="GET" style="display:flex;gap:10px;margin-bottom:24px">
            <input type="text" name="q" value="{{ $q }}" placeholder="Cari game, konsol, aksesoris...">
            <button class="btn btn-red">Cari</button>
        </form>
    @endisset

    <p style="color:var(--muted);font-size:14px;margin:0 0 20px">Menampilkan {{ $products->count() }} dari {{ $products->total() }} produk</p>

    @if ($products->isEmpty())
        <div class="empty">Produk tidak ditemukan.</div>
    @else
        <div class="products">
            @foreach ($products as $p) @include('partials.product-card') @endforeach
        </div>
        @include('partials.pagination', ['paginator' => $products, 'pageUrl' => $pageUrl])
    @endif
@endsection
