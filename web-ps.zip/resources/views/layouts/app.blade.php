<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Toko Game PS5, PS4, XBOX Original') — {{ config('app.name') }}</title>
    <meta name="description" content="Jual game & konsol PS5, PS4, XBOX original bergaransi resmi.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}?v=1">
</head>
<body>
@php $brand = strtoupper(str_replace(' ', '', config('app.name'))); @endphp
<header class="header">
    <div class="container header-inner">
        <a href="{{ route('home') }}" class="logo">{{ $brand }}</a>

        <nav class="nav" id="mainNav">
            <a href="{{ route('home') }}" @class(['active' => request()->routeIs('home')])>Home</a>
            <div class="dd">
                <span>Shop &#9662;</span>
                <div class="mega">
                    @foreach ($menu as $platform => $cats)
                        <div>
                            <h6>{{ $platform }}</h6>
                            @foreach ($cats as $c)
                                <a href="{{ $c->url() }}">{{ $c->name }}</a>
                            @endforeach
                            @if ($platform !== 'Others')
                                <a href="{{ route('preorder', strtolower($platform)) }}">Preorder {{ $platform }}</a>
                            @endif
                        </div>
                    @endforeach
                </div>
            </div>
            <a href="{{ route('promo') }}" @class(['active' => request()->routeIs('promo')])>Promo</a>
            <a href="{{ route('payment.form') }}" @class(['active' => request()->routeIs('payment.*')])>Konfirmasi Bayar</a>
            <a href="{{ route('contact') }}" @class(['active' => request()->routeIs('contact')])>Contact Us</a>
        </nav>

        <div class="header-actions">
            @auth
                <div class="user-menu">
                    <button class="icon-btn" data-toggle-user title="Akun">@include('partials.icon', ['n' => 'user'])</button>
                    <div class="menu">
                        <div style="padding:8px 12px;font-size:13px;color:var(--muted)">Halo, <b style="color:var(--text)">{{ auth()->user()->name }}</b></div>
                        <a href="{{ route('orders.index') }}">Pesanan Saya</a>
                        <a href="{{ route('payment.form') }}">Konfirmasi Pembayaran</a>
                        @if (auth()->user()->is_admin)
                            <a href="{{ route('admin.orders.index') }}">Panel Admin</a>
                        @endif
                        <form method="POST" action="{{ route('logout') }}">@csrf<button type="submit">Logout</button></form>
                    </div>
                </div>
            @else
                <a href="{{ route('login') }}">login</a>
            @endauth
            <button class="icon-btn" data-toggle-search title="Cari">@include('partials.icon', ['n' => 'search'])</button>
            <a href="{{ route('cart.index') }}" class="icon-btn" title="Keranjang">
                @include('partials.icon', ['n' => 'cart'])
                <span class="badge">{{ $cartCount }}</span>
            </a>
            <button class="icon-btn burger" data-toggle-nav>@include('partials.icon', ['n' => 'menu'])</button>
        </div>
    </div>
    <div class="container search-bar" id="searchBar">
        <form action="{{ route('search') }}" method="GET">
            <input type="text" name="q" value="{{ request('q') }}" placeholder="Cari game, konsol, aksesoris...">
            <button class="btn btn-red">Cari</button>
        </form>
    </div>
</header>

<main class="container">
    @include('partials.flash')
    @yield('content')

    <section class="newsletter">
        <div>
            <h2>Dapatkan info promo &amp; rilis game terbaru</h2>
            <p style="margin:8px 0 0;opacity:.85;font-size:14px">Masukkan email kamu dan subscribe ke newsletter kami.</p>
        </div>
        <form method="POST" action="{{ route('subscribe') }}">
            @csrf
            <input type="email" name="newsletterEmail" placeholder="Email kamu" required>
            <button class="btn btn-dark">Go!</button>
        </form>
        <div class="ghost-sm">GAME</div>
    </section>
</main>

<footer class="footer">
    <div class="container">
        <div class="footer-grid">
            <div>
                <div class="logo" style="margin-bottom:12px">{{ $brand }}</div>
                <p style="margin:0;max-width:280px">Toko game terpercaya. Jual konsol, game &amp; aksesoris PS5, PS4, XBOX original bergaransi resmi.</p>
            </div>
            <div>
                <h5>Belanja</h5>
                @foreach (['PS5', 'PS4', 'XBOX', 'Others'] as $pf)
                    @if ($menu->has($pf))<a href="{{ $menu[$pf]->first()->url() }}">{{ $pf }}</a>@endif
                @endforeach
                <a href="{{ route('promo') }}">Promo</a>
            </div>
            <div>
                <h5>Informasi</h5>
                <a href="{{ route('search') }}">Cari Games</a>
                <a href="{{ route('payment.form') }}">Konfirmasi Pembayaran</a>
                <a href="{{ route('privacy') }}">Kebijakan Privasi</a>
                <a href="{{ route('terms') }}">Syarat &amp; Ketentuan</a>
                <a href="{{ route('contact') }}">Hubungi Kami</a>
            </div>
            <div>
                <h5>Contact Us</h5>
                <p style="margin:0 0 6px">{{ config('store.address') }}</p>
                <a href="mailto:{{ config('store.email') }}">{{ config('store.email') }}</a>
                <p style="margin:6px 0 0">{{ config('store.hours') }}</p>
            </div>
        </div>
        <div class="copy"><span>&copy; {{ date('Y') }} {{ config('app.name') }}. All Rights Reserved.</span><span>Dibuat dengan Laravel</span></div>
    </div>
</footer>

<a class="wa-float" target="_blank" rel="noopener" title="Chat WhatsApp"
   href="https://api.whatsapp.com/send?phone={{ config('store.whatsapp') }}&text={{ rawurlencode('Halo, saya mau beli game') }}">
    @include('partials.icon', ['n' => 'wa'])
</a>

<script src="{{ asset('js/app.js') }}?v=1"></script>
</body>
</html>
