<div class="p-card">
    <a href="{{ $p->url() }}" class="thumb">
        @if ($p->is_preorder)
            <span class="tag tag-pre">Preorder</span>
        @elseif ($p->isSoldOut())
            <span class="tag tag-sold">Sold Out</span>
        @elseif ($p->old_price)
            <span class="tag tag-promo">-{{ round(100 - $p->price / $p->old_price * 100) }}%</span>
        @elseif ($p->is_new_release)
            <span class="tag tag-new">New</span>
        @endif
        <img src="{{ $p->imageUrl() }}" alt="{{ $p->name }}" loading="lazy">
    </a>
    <div class="info">
        <a href="{{ $p->url() }}" class="name">{{ $p->name }}</a>
        <div>
            <span class="price">@rupiah($p->price)</span>
            @if ($p->old_price)<span class="old-price">@rupiah($p->old_price)</span>@endif
        </div>
        <div class="actions">
            <a href="{{ $p->url() }}" class="btn btn-outline btn-sm">Detail</a>
            @unless ($p->isSoldOut())
                {{-- Kalau belum login, middleware "auth" mengarahkan ke /login lalu kembali ke sini --}}
                <a href="{{ route('cart.add', $p->id) }}" class="btn btn-red btn-sm">Beli</a>
            @endunless
        </div>
    </div>
</div>
