// Interaksi kecil tanpa framework
document.addEventListener('click', function (e) {
    // toggle search
    if (e.target.closest('[data-toggle-search]')) {
        const bar = document.getElementById('searchBar');
        bar.classList.toggle('open');
        if (bar.classList.contains('open')) bar.querySelector('input').focus();
    }
    // menu mobile
    if (e.target.closest('[data-toggle-nav]')) {
        document.getElementById('mainNav').classList.toggle('open');
    }
    // dropdown user
    const um = e.target.closest('.user-menu');
    document.querySelectorAll('.user-menu').forEach(m => { if (m !== um) m.classList.remove('open'); });
    if (e.target.closest('[data-toggle-user]')) um.classList.toggle('open');
    // dropdown Shop di mobile
    const dd = e.target.closest('.dd > span');
    if (dd) dd.parentElement.classList.toggle('open');
});

// Tab cara pengiriman di keranjang (Ambil Langsung / GOJEK / Grab / JNE / J&T)
(function () {
    const form = document.getElementById('shippingForm');
    if (!form) return;
    const hidden = form.querySelector('[name=jenisongkir]');
    const notes = {
        pickup: 'Ambil langsung di kantor. Harap konfirmasi dulu sebelum datang. Bawa invoice & bukti transfer (bila sudah transfer).',
        gojek: 'Dikirim via GOJEK. Ongkos kirim dibayar langsung ke driver.',
        grab: 'Dikirim via Grab. Ongkos kirim dibayar langsung ke driver.',
        jne: 'JNE: tarif sesuai kota tujuan x berat paket.',
        jnt: 'J&T: tarif sesuai kota tujuan x berat paket.'
    };
    function show(type) {
        hidden.value = type;
        form.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.type === type));
        form.querySelectorAll('[data-show]').forEach(el => {
            el.style.display = el.dataset.show.split(' ').includes(type) ? '' : 'none';
        });
        form.querySelector('.tab-note').textContent = notes[type];
        // radio cash hanya untuk pickup
        const cash = document.querySelector('[data-cash]');
        if (cash) {
            const ok = document.querySelector('[data-current-courier]')?.dataset.currentCourier === 'pickup';
            cash.classList.toggle('disabled', !ok);
        }
    }
    form.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => show(t.dataset.type)));
    show(hidden.value || 'pickup');
})();
