<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Coupon;
use App\Models\Order;
use App\Models\Product;
use App\Models\ShippingRate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

/**
 * Alur flowchart: /beli -> /belanja -> /hitung_ongkir -> /checkout_proses
 * Semua method di sini sudah dilindungi middleware "auth" (wajib login).
 */
class CartController extends Controller
{
    /** GET/POST /beli/{id}/sekarang : tambah ke keranjang milik user yang login */
    public function add(Request $request, Product $product)
    {
        if ($product->isSoldOut()) {
            return redirect($product->url())->with('error', 'Maaf, produk ini sedang Sold Out.');
        }

        $qty = max(1, (int) $request->input('qty', 1));
        $cart = Cart::firstOrNew(['user_id' => $request->user()->id, 'product_id' => $product->id]);
        $newQty = ($cart->exists ? $cart->qty : 0) + $qty;

        if (! $product->is_preorder) {
            $newQty = min($newQty, $product->stock);
        }

        $cart->qty = $newQty;
        $cart->save();

        return redirect()->route('cart.index')->with('success', $product->name.' masuk ke keranjang.');
    }

    /** GET /belanja */
    public function index(Request $request)
    {
        $items = $this->items($request);
        $subtotal = $items->sum(fn ($c) => $c->subtotal());
        $shipping = $this->shippingQuote($request, $items);

        return view('cart.index', [
            'items' => $items,
            'subtotal' => $subtotal,
            'shipping' => $shipping,
            'cities' => ShippingRate::select('city')->distinct()->orderBy('city')->pluck('city'),
            'user' => $request->user(),
        ]);
    }

    public function update(Request $request, Cart $cart)
    {
        abort_unless($cart->user_id === $request->user()->id, 403);
        $qty = max(1, (int) $request->input('qty', 1));
        $product = $cart->product;

        if (! $product->is_preorder && $qty > $product->stock) {
            return back()->with('error', 'Stok '.$product->name.' hanya tersisa '.$product->stock.'.');
        }

        $cart->update(['qty' => $qty]);

        return back();
    }

    public function remove(Request $request, Cart $cart)
    {
        abort_unless($cart->user_id === $request->user()->id, 403);
        $cart->delete();

        return back()->with('success', 'Produk dihapus dari keranjang.');
    }

    public function clear(Request $request)
    {
        Cart::where('user_id', $request->user()->id)->delete();
        $request->session()->forget('shipping');

        return redirect()->route('cart.index')->with('success', 'Keranjang dikosongkan.');
    }

    /** POST /hitung_ongkir : simpan data penerima + jenis pengiriman ke session */
    public function shipping(Request $request)
    {
        $data = $request->validate([
            'jenisongkir' => ['required', Rule::in(array_keys(Order::COURIERS))],
            'namatemp' => ['required', 'string', 'max:100'],
            'hptemp' => ['required', 'string', 'max:20'],
            'emailtemp' => ['required', 'email'],
            'alamattemp' => [Rule::requiredIf($request->jenisongkir !== 'pickup'), 'nullable', 'string', 'max:500'],
            'kotatemp' => [Rule::requiredIf(in_array($request->jenisongkir, ['jne', 'jnt'])), 'nullable', 'string'],
            'ziptemp' => ['nullable', 'string', 'max:10'],
        ], [
            'alamattemp.required' => 'Alamat wajib diisi untuk pengiriman.',
            'kotatemp.required' => 'Pilih kota tujuan untuk JNE / J&T.',
        ]);

        if (in_array($data['jenisongkir'], ['jne', 'jnt'])
            && ! ShippingRate::where('courier', $data['jenisongkir'])->where('city', $data['kotatemp'])->exists()) {
            return back()->withErrors(['kotatemp' => 'Kota belum tersedia untuk kurir ini.'])->withInput();
        }

        $request->session()->put('shipping', $data);

        return redirect()->to(route('cart.index').'#pembayaran')->with('success', 'Ongkos kirim sudah dihitung. Silakan pilih cara pembayaran.');
    }

    /** POST /checkout_proses : buat invoice */
    public function checkout(Request $request)
    {
        $data = $request->validate([
            'payment_method_id' => ['required', Rule::in(array_keys(Order::PAYMENT_METHODS))],
            'kupon' => ['nullable', 'string', 'max:50'],
            'comment' => ['nullable', 'string', 'max:1000'],
        ]);

        $items = $this->items($request);
        $ship = $request->session()->get('shipping');

        if ($items->isEmpty()) {
            return redirect()->route('cart.index')->with('error', 'Keranjang masih kosong.');
        }
        if (! $ship) {
            return redirect()->route('cart.index')->with('error', 'Pilih cara pengiriman dan klik "Hitung Ongkir" dulu.');
        }
        if ((int) $data['payment_method_id'] === Order::PAYMENT_CASH && $ship['jenisongkir'] !== 'pickup') {
            return back()->with('error', 'Pembayaran cash hanya untuk Ambil Langsung di kantor.');
        }

        $subtotal = $items->sum(fn ($c) => $c->subtotal());
        $coupon = null;
        if (! empty($data['kupon'])) {
            $coupon = Coupon::findValid($data['kupon'], $subtotal);
            if (! $coupon) {
                return back()->withInput()->with('error', 'Kupon tidak valid, kedaluwarsa, atau belum memenuhi minimal belanja.');
            }
        }

        $discount = $coupon ? $coupon->discountFor($subtotal) : 0;
        $shippingCost = $this->shippingQuote($request, $items)['cost'];

        try {
            $order = DB::transaction(function () use ($request, $items, $ship, $data, $subtotal, $discount, $coupon, $shippingCost) {
                // Kunci baris produk agar stok tidak dobel terjual
                foreach ($items as $item) {
                    $p = Product::lockForUpdate()->find($item->product_id);
                    if (! $p->is_preorder && $p->stock < $item->qty) {
                        throw ValidationException::withMessages(['stok' => "Stok {$p->name} tidak cukup (sisa {$p->stock})."]);
                    }
                    if ($p->stock > 0) {
                        $p->decrement('stock', min($item->qty, $p->stock));
                    }
                }

                $order = Order::create([
                    'invoice' => Order::makeInvoice(),
                    'user_id' => $request->user()->id,
                    'customer_name' => $ship['namatemp'],
                    'phone' => $ship['hptemp'],
                    'email' => $ship['emailtemp'],
                    'address' => $ship['alamattemp'] ?? null,
                    'city' => $ship['kotatemp'] ?? null,
                    'zip' => $ship['ziptemp'] ?? null,
                    'courier' => $ship['jenisongkir'],
                    'shipping_cost' => $shippingCost,
                    'payment_method_id' => $data['payment_method_id'],
                    'subtotal' => $subtotal,
                    'discount' => $discount,
                    'coupon_code' => $coupon?->code,
                    'grand_total' => $subtotal - $discount + $shippingCost,
                    'note' => $data['comment'] ?? null,
                ]);

                foreach ($items as $item) {
                    $order->items()->create([
                        'product_id' => $item->product_id,
                        'product_name' => $item->product->name,
                        'price' => $item->product->price,
                        'qty' => $item->qty,
                        'subtotal' => $item->subtotal(),
                    ]);
                }

                Cart::where('user_id', $request->user()->id)->delete();

                return $order;
            });
        } catch (ValidationException $e) {
            return redirect()->route('cart.index')->with('error', $e->validator->errors()->first());
        }

        $request->session()->forget('shipping');

        return redirect()->route('orders.show', $order->invoice)
            ->with('success', 'Pesanan berhasil dibuat! Nomor invoice: '.$order->invoice);
    }

    // ----------------------------------------------------------------

    private function items(Request $request)
    {
        return Cart::with('product')->where('user_id', $request->user()->id)->get();
    }

    /** Hitung ongkir dari data di session. JNE/J&T = tarif kota x berat (dibulatkan ke atas, min 1 kg). */
    private function shippingQuote(Request $request, $items): array
    {
        $ship = $request->session()->get('shipping');
        if (! $ship) {
            return ['data' => null, 'cost' => 0, 'note' => null];
        }

        $weight = max(1, (int) ceil($items->sum(fn ($c) => $c->qty * $c->product->weight)));
        $cost = 0;
        $note = null;

        switch ($ship['jenisongkir']) {
            case 'jne':
            case 'jnt':
                $rate = ShippingRate::where('courier', $ship['jenisongkir'])->where('city', $ship['kotatemp'])->value('cost') ?? 0;
                $cost = $rate * $weight;
                $note = "{$weight} kg x Rp ".number_format($rate, 0, ',', '.');
                break;
            case 'gojek':
            case 'grab':
                $note = 'Ongkir dibayar langsung ke driver';
                break;
            default:
                $note = 'Ambil di kantor ('.config('store.hours').')';
        }

        return ['data' => $ship, 'cost' => $cost, 'note' => $note, 'weight' => $weight];
    }
}
