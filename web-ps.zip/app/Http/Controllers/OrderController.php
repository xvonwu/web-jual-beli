<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    /** Riwayat pesanan milik user */
    public function index(Request $request)
    {
        $orders = $request->user()->orders()->latest()->paginate(10);

        return view('orders.index', compact('orders'));
    }

    /** /invoice/{invoice} */
    public function show(Request $request, string $invoice)
    {
        $order = Order::with(['items', 'confirmations'])->where('invoice', $invoice)->firstOrFail();
        abort_unless($order->user_id === $request->user()->id || $request->user()->is_admin, 403);

        return view('orders.show', compact('order'));
    }

    /** /payment_confirm : form pelunasan (wajib login), invoice dipilih dari akun */
    public function paymentForm(Request $request)
    {
        $orders = $request->user()->orders()
            ->where('status', 'menunggu_pembayaran')
            ->where('payment_method_id', Order::PAYMENT_TRANSFER)
            ->latest()->get();

        return view('orders.payment', [
            'orders' => $orders,
            'selected' => $request->query('invoice'),
            'user' => $request->user(),
        ]);
    }

    /** POST /payment_confirm_save */
    public function paymentSave(Request $request)
    {
        $data = $request->validate([
            'invoice' => ['required', 'string'],
            'email' => ['required', 'email'],
            'nama' => ['required', 'string', 'max:100'],
            'tgl_transfer' => ['required', 'date', 'before_or_equal:today'],
            'jml_transfer' => ['required', 'integer', 'min:1'],
            'rekening_tujuan' => ['required', 'string', 'max:100'],
            'dari_bank' => ['required', 'string', 'max:50'],
            'rekening_pengirim' => ['required', 'string', 'max:100'],
        ]);

        $order = $request->user()->orders()->where('invoice', $data['invoice'])->first();

        if (! $order || $order->status !== 'menunggu_pembayaran') {
            return back()->withInput()->withErrors(['invoice' => 'Invoice tidak ditemukan atau sudah dikonfirmasi.']);
        }

        $order->confirmations()->create(collect($data)->except('invoice')->all() + ['user_id' => $request->user()->id]);
        $order->update(['status' => 'menunggu_verifikasi']);

        return redirect()->route('orders.show', $order->invoice)
            ->with('success', 'Konfirmasi pembayaran terkirim. Admin akan memverifikasi di hari & jam kerja.');
    }
}
