<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;

class HomeController extends Controller
{
    public function index()
    {
        return view('home', [
            'newReleases' => Product::where('is_new_release', true)->latest('release_date')->take(8)->get(),
            'latest' => Product::latest('updated_at')->take(8)->get(),
            'preorders' => Product::where('is_preorder', true)->take(4)->get(),
            'cat' => Category::all()->keyBy('id'), // untuk link kartu kategori di home
        ]);
    }
}
